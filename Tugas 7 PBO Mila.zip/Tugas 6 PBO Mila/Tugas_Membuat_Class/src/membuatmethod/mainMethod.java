/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package membuatmethod;

/**
 *
 * @author ASUS
 */
public class mainMethod {

    public static void main(String[] args) {
        
        int Penjumlahan;
        int Perkalian;
        int Pengurangan;
        int Pembagian;
        
        calculator angka = new calculator();
        Penjumlahan = angka.getPenjumlahan(10,12);
        Perkalian = angka.getPerkalian(10,5);
        Pengurangan = angka.getPengurangan(20,8);
        Pembagian = angka.getPembagian(50,5);
          
        System.out.println("--Ini Merupakan Program Calculator--");
        System.out.println("");
        System.out.println("Hasil Dari Penjumlahan Adalah "+Penjumlahan);
        System.out.println("Hasil Dari Perkalian Adalah "+Perkalian);
        System.out.println("Hasil Dari Pengurangan Adalah "+Pengurangan);
        System.out.println("Hasil Dari Pembagian Adalah "+Pembagian);
    }
    
}
