/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package membuatmethod;

/**
 *
 * @author ASUS
 */
public class calculator {
    
    public int getPenjumlahan(int a, int b) {
        int Penjumlahan = a + b ;
        return Penjumlahan ;
    }
    public int getPerkalian(int a, int b) {
        int Perkalian = a * b ;
        return Perkalian ;
    }
    public int getPengurangan(int a, int b) {
        int Pengurangan = a - b ;
        return Pengurangan ;
    }
    public int getPembagian(int a, int b) {
        int Pembagian = a / b ;
        return Pembagian ;
    }
    public void statusProgram(){
        System.out.println("--Ini Merupakan Program Calculator--");
    }
}
